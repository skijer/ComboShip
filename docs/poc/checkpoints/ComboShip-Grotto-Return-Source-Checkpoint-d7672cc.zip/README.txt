ComboShip MM Grotto Return Source Checkpoint

Commit: d7672cc2267df2a5531db6788d3645300ba73d09
Branch: fix/mm-grotto-return-arrival-20261017
Parent baseline: 43131342882972eeb4a257599ec8b061c7dc6d43
Baseline branch: integration/big-merge-20261016

Status: implemented source candidate for the cumulative merge.
Runtime validation and user acceptance remain pending.

Change
MM cross-game return/recovery setup clears stale pause-save and owl-save
arrival markers. This preserves the native jump out of an MM grotto instead
of forcing a stationary spawn over the hole. Existing route maps, spawn
descriptors, seasonal fallbacks and ordinary save resumes are preserved.

Verification
- New startup regression reproduced the failure before the correction.
- All 24 MM hole returns and native-resume controls passed afterward.
- Focused address/undefined-behavior sanitizer fixture passed.
- All 45 entrance regression commands completed across resumed runs.
- Independent review found no blocking findings.
- The patch was replayed against the exact parent and recreated the candidate
  tree: 5f72b534c88c1ce7e4977b9055ce8b98a8d173fa.
- The incremental Git bundle was verified against its parent prerequisite.

Cumulative merge using the bundle
Run these commands in the cumulative source repository, with the checkpoint
files accessible from the current directory. Fetch the parent baseline if
it is not already present:

git fetch origin integration/big-merge-20261016
git fetch ./ComboShip-Grotto-Return-d7672cc.bundle refs/heads/fix/mm-grotto-return-arrival-20261017
git cherry-pick d7672cc2267df2a5531db6788d3645300ba73d09

The bundle contains only the new commit and requires the parent baseline.
Use the patch as an alternative import route:

git apply --3way --index ./mm-grotto-return-source-fix.patch

Use one import route. Review normal cherry-pick conflicts if another
cumulative candidate changes the same title-setup area. The source delta
includes its focused regressions and POC record; it includes no game binaries
or asset archive changes.

Next runtime check
Repeat the shown grave-to-MM-grotto return. Verify that Link jumps clear,
can remain still outside the hole, and can intentionally re-enter.
